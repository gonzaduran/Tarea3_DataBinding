package es.medac.euroyenconverter;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText eurosInput;
    private TextView resultadoYenes;
    private static final double TASA_CAMBIO = 160.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        // 1. Vinculación Manual (findViewById)
        eurosInput = findViewById(R.id.et_euros_input);
        resultadoYenes = findViewById(R.id.tv_resultado_yenes);
        Button convertirButton = findViewById(R.id.btn_convertir);

        // 2. Establecer el Listener (manejar la acción)
        convertirButton.setOnClickListener(v -> {
            convertirEuros(); // Llama al método de cálculo y actualización
        });
    }


    private void convertirEuros() {
        String eurosStr = eurosInput.getText().toString();

        // 1. Comprobar si está vacío
        if (eurosStr.trim().isEmpty()) {
            resultadoYenes.setText(getString(R.string.error_vacio));
            return;
        }

        try {
            // 2. Cálculo
            double euros = Double.parseDouble(eurosStr);
            double yenes = euros * TASA_CAMBIO;

            // 3. Actualizar la Vista Manualmente (Cálculo exitoso)

            String resultadoFormateado = String.format(getString(R.string.resultado_yenes), String.format("%.2f", yenes));

            // Reemplazamos el bloque if anterior:
            // if (/* cálculo fue exitoso */) {
            resultadoYenes.setText(resultadoFormateado);
            /* } else {
                 resultadoYenes.setText(getString(R.string.error_vacio));
            } */

        } catch (NumberFormatException e) {
            // Error si el texto no es un número válido
            resultadoYenes.setText(getString(R.string.error_vacio));
        }
    }
}